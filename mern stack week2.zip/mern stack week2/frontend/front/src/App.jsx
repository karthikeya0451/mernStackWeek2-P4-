import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import SignUp from './components/SignUp';
import Login from './components/Login';
import Home from './components/Home';
import Delete from './components/AdminProducts/ProductList';
import Add from './components/AdminProducts/AddProduct';
import Admin from './components/AdminProducts/AdminDashBoard';
import ProductPage from './components/ProductPage';
// import AppRoutes  from './components/AppRoutes';
function App() {
  return (
    <Router>
       <Navbar />
      <div>
        <Routes>
        <Route path="/product" element={<ProductPage/>}/>
        <Route path="/add" element={<Add/>}/>
          <Route path="/delete" element={<Delete/>}/>
        <Route path="/" element={<Home/>} />
          <Route path="/signup" element={<SignUp />} />
         <Route path="/admin" element={<Admin/>}/>
          <Route path="/login" element={<Login />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
